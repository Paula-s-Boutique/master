﻿namespace PaulasBoutique
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.TitleWelcome = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.CustomerPage = new System.Windows.Forms.TabPage();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.btnSignInCust = new System.Windows.Forms.Button();
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.tbxMember = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pageEmployee = new System.Windows.Forms.TabPage();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.tbxEmpPIN = new System.Windows.Forms.TextBox();
            this.tbxEmpID = new System.Windows.Forms.TextBox();
            this.tbxMgmtPIN = new System.Windows.Forms.TextBox();
            this.tbxMmgtID = new System.Windows.Forms.TextBox();
            this.SignInMgmt = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.SignInEmp = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.cbxSignInChoice = new System.Windows.Forms.ComboBox();
            this.pageProduct = new System.Windows.Forms.TabPage();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pageCompany = new System.Windows.Forms.TabPage();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pageContact = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.tbxLast = new System.Windows.Forms.TextBox();
            this.tbxComments = new System.Windows.Forms.TextBox();
            this.tbxEmail = new System.Windows.Forms.TextBox();
            this.tbxNumber = new System.Windows.Forms.TextBox();
            this.tbxFirst = new System.Windows.Forms.TextBox();
            this.btnNewSubmission = new System.Windows.Forms.Button();
            this.btnSubmitContact = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabControl.SuspendLayout();
            this.CustomerPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.pageEmployee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.pageProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            this.pageCompany.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.pageContact.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // TitleWelcome
            // 
            this.TitleWelcome.AutoSize = true;
            this.TitleWelcome.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TitleWelcome.Location = new System.Drawing.Point(111, 34);
            this.TitleWelcome.Name = "TitleWelcome";
            this.TitleWelcome.Size = new System.Drawing.Size(262, 23);
            this.TitleWelcome.TabIndex = 0;
            this.TitleWelcome.Text = " Welcome to Paula\'s Boutique";
            this.TitleWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(112, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 2;
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.CustomerPage);
            this.tabControl.Controls.Add(this.pageEmployee);
            this.tabControl.Controls.Add(this.pageProduct);
            this.tabControl.Controls.Add(this.pageCompany);
            this.tabControl.Controls.Add(this.pageContact);
            this.tabControl.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl.Location = new System.Drawing.Point(38, 94);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(420, 362);
            this.tabControl.TabIndex = 3;
            // 
            // CustomerPage
            // 
            this.CustomerPage.BackColor = System.Drawing.Color.Pink;
            this.CustomerPage.Controls.Add(this.pictureBox14);
            this.CustomerPage.Controls.Add(this.pictureBox13);
            this.CustomerPage.Controls.Add(this.pictureBox12);
            this.CustomerPage.Controls.Add(this.pictureBox11);
            this.CustomerPage.Controls.Add(this.pictureBox10);
            this.CustomerPage.Controls.Add(this.pictureBox9);
            this.CustomerPage.Controls.Add(this.pictureBox8);
            this.CustomerPage.Controls.Add(this.pictureBox6);
            this.CustomerPage.Controls.Add(this.pictureBox7);
            this.CustomerPage.Controls.Add(this.btnSignInCust);
            this.CustomerPage.Controls.Add(this.tbxPassword);
            this.CustomerPage.Controls.Add(this.tbxMember);
            this.CustomerPage.Controls.Add(this.label8);
            this.CustomerPage.Controls.Add(this.label7);
            this.CustomerPage.Controls.Add(this.label6);
            this.CustomerPage.Location = new System.Drawing.Point(4, 23);
            this.CustomerPage.Name = "CustomerPage";
            this.CustomerPage.Padding = new System.Windows.Forms.Padding(3);
            this.CustomerPage.Size = new System.Drawing.Size(412, 335);
            this.CustomerPage.TabIndex = 0;
            this.CustomerPage.Text = "Customer Login";
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(230, 268);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(43, 39);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 14;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(188, 254);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(47, 40);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 13;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(230, 172);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(43, 36);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 12;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(241, 224);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(51, 47);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 11;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(269, 163);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(62, 55);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 10;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(288, 215);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(62, 47);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 9;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(230, 129);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(62, 47);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 8;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(258, 29);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(62, 47);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 7;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(288, 82);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(90, 75);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            // 
            // btnSignInCust
            // 
            this.btnSignInCust.Location = new System.Drawing.Point(97, 183);
            this.btnSignInCust.Name = "btnSignInCust";
            this.btnSignInCust.Size = new System.Drawing.Size(78, 35);
            this.btnSignInCust.TabIndex = 5;
            this.btnSignInCust.Text = "Log In";
            this.btnSignInCust.UseVisualStyleBackColor = true;
            // 
            // tbxPassword
            // 
            this.tbxPassword.Location = new System.Drawing.Point(56, 129);
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(154, 20);
            this.tbxPassword.TabIndex = 4;
            this.tbxPassword.TextChanged += new System.EventHandler(this.tbxPassword_TextChanged);
            // 
            // tbxMember
            // 
            this.tbxMember.Location = new System.Drawing.Point(56, 70);
            this.tbxMember.Name = "tbxMember";
            this.tbxMember.Size = new System.Drawing.Size(154, 20);
            this.tbxMember.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(53, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 14);
            this.label8.TabIndex = 2;
            this.label8.Text = "Password: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(53, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 14);
            this.label7.TabIndex = 1;
            this.label7.Text = "Member ID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(53, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "Please Sign in:";
            // 
            // pageEmployee
            // 
            this.pageEmployee.BackColor = System.Drawing.Color.Pink;
            this.pageEmployee.Controls.Add(this.pictureBox5);
            this.pageEmployee.Controls.Add(this.pictureBox4);
            this.pageEmployee.Controls.Add(this.tbxEmpPIN);
            this.pageEmployee.Controls.Add(this.tbxEmpID);
            this.pageEmployee.Controls.Add(this.tbxMgmtPIN);
            this.pageEmployee.Controls.Add(this.tbxMmgtID);
            this.pageEmployee.Controls.Add(this.SignInMgmt);
            this.pageEmployee.Controls.Add(this.label11);
            this.pageEmployee.Controls.Add(this.label12);
            this.pageEmployee.Controls.Add(this.label10);
            this.pageEmployee.Controls.Add(this.label9);
            this.pageEmployee.Controls.Add(this.SignInEmp);
            this.pageEmployee.Controls.Add(this.label5);
            this.pageEmployee.Controls.Add(this.cbxSignInChoice);
            this.pageEmployee.Location = new System.Drawing.Point(4, 23);
            this.pageEmployee.Name = "pageEmployee";
            this.pageEmployee.Padding = new System.Windows.Forms.Padding(3);
            this.pageEmployee.Size = new System.Drawing.Size(412, 335);
            this.pageEmployee.TabIndex = 1;
            this.pageEmployee.Text = "Employee Login";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(323, 25);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(63, 294);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 17;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(27, 25);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(63, 294);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 16;
            this.pictureBox4.TabStop = false;
            // 
            // tbxEmpPIN
            // 
            this.tbxEmpPIN.Location = new System.Drawing.Point(124, 192);
            this.tbxEmpPIN.Name = "tbxEmpPIN";
            this.tbxEmpPIN.Size = new System.Drawing.Size(164, 20);
            this.tbxEmpPIN.TabIndex = 15;
            // 
            // tbxEmpID
            // 
            this.tbxEmpID.Location = new System.Drawing.Point(124, 136);
            this.tbxEmpID.Name = "tbxEmpID";
            this.tbxEmpID.Size = new System.Drawing.Size(164, 20);
            this.tbxEmpID.TabIndex = 14;
            // 
            // tbxMgmtPIN
            // 
            this.tbxMgmtPIN.Location = new System.Drawing.Point(124, 192);
            this.tbxMgmtPIN.Name = "tbxMgmtPIN";
            this.tbxMgmtPIN.Size = new System.Drawing.Size(164, 20);
            this.tbxMgmtPIN.TabIndex = 13;
            // 
            // tbxMmgtID
            // 
            this.tbxMmgtID.Location = new System.Drawing.Point(124, 136);
            this.tbxMmgtID.Name = "tbxMmgtID";
            this.tbxMmgtID.Size = new System.Drawing.Size(164, 20);
            this.tbxMmgtID.TabIndex = 12;
            // 
            // SignInMgmt
            // 
            this.SignInMgmt.Location = new System.Drawing.Point(167, 246);
            this.SignInMgmt.Name = "SignInMgmt";
            this.SignInMgmt.Size = new System.Drawing.Size(78, 36);
            this.SignInMgmt.TabIndex = 11;
            this.SignInMgmt.Text = "Login";
            this.SignInMgmt.UseVisualStyleBackColor = true;
            this.SignInMgmt.Click += new System.EventHandler(this.SignInMgmt_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(121, 175);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 14);
            this.label11.TabIndex = 10;
            this.label11.Text = "Manager PIN:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(121, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 14);
            this.label12.TabIndex = 9;
            this.label12.Text = "Manager ID:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(121, 175);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 14);
            this.label10.TabIndex = 8;
            this.label10.Text = "Employee PIN:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(121, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 14);
            this.label9.TabIndex = 7;
            this.label9.Text = "Employee ID:";
            // 
            // SignInEmp
            // 
            this.SignInEmp.Location = new System.Drawing.Point(167, 246);
            this.SignInEmp.Name = "SignInEmp";
            this.SignInEmp.Size = new System.Drawing.Size(78, 36);
            this.SignInEmp.TabIndex = 6;
            this.SignInEmp.Text = "Login";
            this.SignInEmp.UseVisualStyleBackColor = true;
            this.SignInEmp.Click += new System.EventHandler(this.SignInEmp_Click);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(131, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(175, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Please Select Login Type: ";
            // 
            // cbxSignInChoice
            // 
            this.cbxSignInChoice.FormattingEnabled = true;
            this.cbxSignInChoice.Items.AddRange(new object[] {
            "Employee",
            "Management"});
            this.cbxSignInChoice.Location = new System.Drawing.Point(121, 75);
            this.cbxSignInChoice.Name = "cbxSignInChoice";
            this.cbxSignInChoice.Size = new System.Drawing.Size(167, 22);
            this.cbxSignInChoice.TabIndex = 0;
            this.cbxSignInChoice.SelectedIndexChanged += new System.EventHandler(this.cbxSignInChoice_SelectedIndexChanged);
            // 
            // pageProduct
            // 
            this.pageProduct.BackColor = System.Drawing.Color.Pink;
            this.pageProduct.Controls.Add(this.pictureBox16);
            this.pageProduct.Controls.Add(this.pictureBox15);
            this.pageProduct.Controls.Add(this.label17);
            this.pageProduct.Controls.Add(this.label4);
            this.pageProduct.Location = new System.Drawing.Point(4, 23);
            this.pageProduct.Name = "pageProduct";
            this.pageProduct.Padding = new System.Windows.Forms.Padding(3);
            this.pageProduct.Size = new System.Drawing.Size(412, 335);
            this.pageProduct.TabIndex = 2;
            this.pageProduct.Text = "Product List";
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox16.Image")));
            this.pictureBox16.Location = new System.Drawing.Point(332, 17);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(63, 294);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 18;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(17, 17);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(63, 294);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 17;
            this.pictureBox15.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(224, 40);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(107, 238);
            this.label17.TabIndex = 1;
            this.label17.Text = "Dresswear:\r\n\r\nDresses\r\nPantsuits\r\nTuxedos\r\nSkirts \r\nSlacks\r\nBlouses\r\n\r\nAccessorie" +
    "s:\r\n\r\nMen\'s Jewelry\r\nWomen\'s Jewelry\r\nTies\r\nGloves \r\nSocks\r\nScarves\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(86, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 196);
            this.label4.TabIndex = 0;
            this.label4.Text = "Shirts: \r\n\r\nTees\r\nV-Necks\r\nTank-Tops\r\nCollar Shirts\r\n\r\nShoes:\r\n\r\nWomen\'s Dresswea" +
    "r\r\nMen\'s Dresswear\r\nAthletic\r\nSummer Style\r\nBoots\r\n";
            // 
            // pageCompany
            // 
            this.pageCompany.BackColor = System.Drawing.Color.Pink;
            this.pageCompany.Controls.Add(this.pictureBox3);
            this.pageCompany.Controls.Add(this.label3);
            this.pageCompany.Location = new System.Drawing.Point(4, 23);
            this.pageCompany.Name = "pageCompany";
            this.pageCompany.Padding = new System.Windows.Forms.Padding(3);
            this.pageCompany.Size = new System.Drawing.Size(412, 335);
            this.pageCompany.TabIndex = 3;
            this.pageCompany.Text = "About the Company";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(122, 110);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(179, 176);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(376, 167);
            this.label3.TabIndex = 0;
            this.label3.Text = resources.GetString("label3.Text");
            // 
            // pageContact
            // 
            this.pageContact.BackColor = System.Drawing.Color.Pink;
            this.pageContact.Controls.Add(this.label18);
            this.pageContact.Controls.Add(this.tbxLast);
            this.pageContact.Controls.Add(this.tbxComments);
            this.pageContact.Controls.Add(this.tbxEmail);
            this.pageContact.Controls.Add(this.tbxNumber);
            this.pageContact.Controls.Add(this.tbxFirst);
            this.pageContact.Controls.Add(this.btnNewSubmission);
            this.pageContact.Controls.Add(this.btnSubmitContact);
            this.pageContact.Controls.Add(this.label16);
            this.pageContact.Controls.Add(this.label15);
            this.pageContact.Controls.Add(this.label14);
            this.pageContact.Controls.Add(this.label13);
            this.pageContact.Controls.Add(this.label1);
            this.pageContact.Location = new System.Drawing.Point(4, 23);
            this.pageContact.Name = "pageContact";
            this.pageContact.Padding = new System.Windows.Forms.Padding(3);
            this.pageContact.Size = new System.Drawing.Size(412, 335);
            this.pageContact.TabIndex = 4;
            this.pageContact.Text = "Contact Us";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(110, 113);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(189, 36);
            this.label18.TabIndex = 12;
            this.label18.Text = "Your Contact Information \r\nHas been Submitted!";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbxLast
            // 
            this.tbxLast.Location = new System.Drawing.Point(229, 45);
            this.tbxLast.Name = "tbxLast";
            this.tbxLast.Size = new System.Drawing.Size(122, 20);
            this.tbxLast.TabIndex = 11;
            // 
            // tbxComments
            // 
            this.tbxComments.Location = new System.Drawing.Point(59, 188);
            this.tbxComments.Multiline = true;
            this.tbxComments.Name = "tbxComments";
            this.tbxComments.Size = new System.Drawing.Size(292, 53);
            this.tbxComments.TabIndex = 10;
            // 
            // tbxEmail
            // 
            this.tbxEmail.Location = new System.Drawing.Point(59, 143);
            this.tbxEmail.Name = "tbxEmail";
            this.tbxEmail.Size = new System.Drawing.Size(183, 20);
            this.tbxEmail.TabIndex = 9;
          
            // 
            // tbxNumber
            // 
            this.tbxNumber.Location = new System.Drawing.Point(59, 94);
            this.tbxNumber.Name = "tbxNumber";
            this.tbxNumber.Size = new System.Drawing.Size(136, 20);
            this.tbxNumber.TabIndex = 8;
            // 
            // tbxFirst
            // 
            this.tbxFirst.Location = new System.Drawing.Point(60, 45);
            this.tbxFirst.Name = "tbxFirst";
            this.tbxFirst.Size = new System.Drawing.Size(126, 20);
            this.tbxFirst.TabIndex = 7;
            // 
            // btnNewSubmission
            // 
            this.btnNewSubmission.Location = new System.Drawing.Point(151, 261);
            this.btnNewSubmission.Name = "btnNewSubmission";
            this.btnNewSubmission.Size = new System.Drawing.Size(95, 39);
            this.btnNewSubmission.TabIndex = 6;
            this.btnNewSubmission.Text = "New Submission";
            this.btnNewSubmission.UseVisualStyleBackColor = true;
            this.btnNewSubmission.Click += new System.EventHandler(this.btnNewSubmission_Click);
            // 
            // btnSubmitContact
            // 
            this.btnSubmitContact.Location = new System.Drawing.Point(151, 261);
            this.btnSubmitContact.Name = "btnSubmitContact";
            this.btnSubmitContact.Size = new System.Drawing.Size(95, 39);
            this.btnSubmitContact.TabIndex = 5;
            this.btnSubmitContact.Text = "Submit";
            this.btnSubmitContact.UseVisualStyleBackColor = true;
            this.btnSubmitContact.Click += new System.EventHandler(this.btnSubmitContact_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(56, 126);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 14);
            this.label16.TabIndex = 4;
            this.label16.Text = "Email: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(226, 28);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 14);
            this.label15.TabIndex = 3;
            this.label15.Text = "Last Name:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(56, 77);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(157, 14);
            this.label14.TabIndex = 2;
            this.label14.Text = "Phone Number (optional):";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(58, 171);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 14);
            this.label13.TabIndex = 1;
            this.label13.Text = "Comments:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(387, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(90, 75);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 13);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(90, 75);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(493, 481);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TitleWelcome);
            this.Cursor = System.Windows.Forms.Cursors.No;
            this.Name = "frmMain";
            this.Text = "Paula\'s Boutique";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.tabControl.ResumeLayout(false);
            this.CustomerPage.ResumeLayout(false);
            this.CustomerPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.pageEmployee.ResumeLayout(false);
            this.pageEmployee.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.pageProduct.ResumeLayout(false);
            this.pageProduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            this.pageCompany.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.pageContact.ResumeLayout(false);
            this.pageContact.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label TitleWelcome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage CustomerPage;
        private System.Windows.Forms.TabPage pageEmployee;
        private System.Windows.Forms.TabPage pageProduct;
        private System.Windows.Forms.TabPage pageCompany;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnSignInCust;
        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.TextBox tbxMember;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button SignInMgmt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button SignInEmp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbxSignInChoice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage pageContact;
        private System.Windows.Forms.TextBox tbxMgmtPIN;
        private System.Windows.Forms.TextBox tbxMmgtID;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnSubmitContact;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxEmpPIN;
        private System.Windows.Forms.TextBox tbxEmpID;
        private System.Windows.Forms.TextBox tbxLast;
        private System.Windows.Forms.TextBox tbxComments;
        private System.Windows.Forms.TextBox tbxEmail;
        private System.Windows.Forms.TextBox tbxNumber;
        private System.Windows.Forms.TextBox tbxFirst;
        private System.Windows.Forms.Button btnNewSubmission;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox15;
    }
}

