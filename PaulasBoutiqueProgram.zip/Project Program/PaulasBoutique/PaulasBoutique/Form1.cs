﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Members;
using Employees;
using Managers;
using Materials;

namespace PaulasBoutique
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        private void frmMain_Load(object sender, EventArgs e)
        {
            //labels from employee login invisible when loading
            label12.Visible = false; //manager
            label9.Visible = false; //employee
            label11.Visible = false;//manager 
            label10.Visible = false;//employee
            label18.Visible = false; //contact info submitted
            SignInEmp.Visible = false;
            SignInMgmt.Visible = false;
            btnNewSubmission.Visible = false;

            //textboxes for employee page
            tbxEmpID.Visible = false;
            tbxEmpPIN.Visible = false;

            tbxMmgtID.Visible = false;
            tbxMgmtPIN.Visible = false;
        }


        //combo box option
        private void cbxSignInChoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxSignInChoice.SelectedItem.Equals("Employee"))
            {
                label9.Visible = true;
                label12.Visible = false;
                label10.Visible = true;
                label11.Visible = false;
                SignInEmp.Visible = true;
                tbxEmpID.Visible = true;
                tbxEmpPIN.Visible = true;
            }
            else if (cbxSignInChoice.SelectedItem.Equals("Management"))
            {
                label12.Visible = true;
                label9.Visible = false;
                label11.Visible = true;
                label10.Visible = false;
                SignInMgmt.Visible = true;
                tbxMmgtID.Visible = true;
                tbxMgmtPIN.Visible = true;

            }
        }

        private void tbxFirst_TextChanged(object sender, KeyPressEventArgs e)
        {
            //if the charactera are not controlled and are not apart of string letters
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {//it will handle what is mot apart of string letters
                e.Handled = true;

            }

        }

        private void tbxEmpID_TextChanged(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {//it will handle whats not apart of int numbers
                e.Handled = true;

            }
        }

        private void tbxMmgtID_TextChanged(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {//it will handle whats not apart of int numbers
                e.Handled = true;

            }
        }

        private void btnSubmitContact_Click(object sender, EventArgs e)
        {

            //textboxes
            tbxFirst.Visible = false;
            tbxLast.Visible = false;
            tbxNumber.Visible = false;
            tbxEmail.Visible = false;
            tbxComments.Visible = false;

            //labels 
            label1.Visible = false;
            label15.Visible = false;
            label14.Visible = false;
            label16.Visible = false;
            label13.Visible = false;
            //submission label
            label18.Visible = true;
            //buttons
            btnSubmitContact.Visible = false;
            btnNewSubmission.Visible = true;
        }

        private void btnNewSubmission_Click(object sender, EventArgs e)
        {
            label18.Visible = false;
            btnNewSubmission.Visible = false;

            btnSubmitContact.Visible = true;
            //labels 
            label1.Visible = true;
            label15.Visible = true;
            label14.Visible = true;
            label16.Visible = true;
            label13.Visible = true;

            //textboxes 
            tbxFirst.Visible = true;
            tbxFirst.Text = "";
            tbxLast.Visible = true;
            tbxLast.Text = "";
            tbxNumber.Visible = true;
            tbxNumber.Text = "";
            tbxEmail.Visible = true;
            tbxEmail.Text = "";
            tbxComments.Visible = true;
            tbxComments.Text = "";

        }
        //manager log in
        private void SignInMgmt_Click(object sender, EventArgs e)
        {
            label12.Visible = false;

            label11.Visible = false;

            SignInMgmt.Visible = false;
            tbxMmgtID.Visible = false;
            tbxMmgtID.Text = "";
            tbxMgmtPIN.Visible = false;
            tbxMgmtPIN.Text = "";
        }
        //employee log in 
        private void SignInEmp_Click(object sender, EventArgs e)
        {
            label9.Visible = false;

            label10.Visible = false;

            SignInEmp.Visible = false;
            tbxEmpID.Visible = false;
            tbxEmpPIN.Visible = false;
            tbxEmpPIN.Text = "";
            tbxEmpID.Text = "";
        }

        private void tbxMember_TextChanged(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {//it will handle whats not apart of int numbers
                e.Handled = true;

            }
        }
        //input
        private void tbxPassword_TextChanged(object sender, EventArgs e)
        {
            if (tbxPassword.Text == "")
            {
                MessageBox.Show("Please enter password");
                tbxPassword.Focus();
                tbxPassword.Clear();

            }
        }

        private void tbxMmgtPIN_TextChanged(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {//it will handle whats not apart of int numbers
                e.Handled = true;

            }
        }
        private void tbxEmpPIN_TextChanged(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {//it will handle whats not apart of int numbers
                e.Handled = true;

            }
        }
        private void tbxLast_TextChanged(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {//it will handle whats not apart of int numbers
                e.Handled = true;

            }
        }
        private void tbxNumber_TextChanged(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {//it will handle whats not apart of int numbers
                e.Handled = true;

            }
        }
       
        private void tbxEmail_TextChanged(object sender, EventArgs e)
        {
            if(tbxEmail.Text == "")
            {
                MessageBox.Show("Please enter email.");
                tbxEmail.Text = "";
                tbxEmail.Focus();
            }
        }
    }
}
